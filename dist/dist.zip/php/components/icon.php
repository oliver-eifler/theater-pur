<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 09.07.2016
 * Time: 18:32
 * social menu components
 */
Component::register("icon",
    function ($iconname) {
        $html = "<!--[if gt IE 8]><!-->";
        $html .= "<svg width='16' height='16' class='icon icon-".$iconname."'>";
        $html .= "<use class='svg-hide' xlink:href='images/icons.svg#icon-".$iconname."'/></svg>";
        $html .= "<!--<![endif]-->";
        return $html;
    });
