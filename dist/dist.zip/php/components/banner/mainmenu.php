<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 10.07.2016
 * Time: 15:58
 */
require_once("php/class/component.class.php");
require_once("php/class/pagedata.class.php");
require_once("php/components/include/mainmenu.php");

Component::autoregister(__FILE__,new MainMenuComponent("mm"));
