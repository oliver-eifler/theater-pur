<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 09.07.2016
 * Time: 17:34
 * Footer Component
 */
require_once("php/class/component.class.php");
require_once("php/class/pagedata.class.php");
require_once("php/class/config.class.php");

class FooterComponent {
    protected $fromYear = 0;
    
    public function __construct($year = null) {
        if (!isset($year))
            $year = (int)date('Y');
        $this->fromYear = $year;
    }
    
    public function __invoke()
    {
        $thisYear = (int)date('Y');
        $Year = $this->fromYear . (($this->fromYear != $thisYear) ? '-' . $thisYear : '');
        $html = "";
        $html.="<p>This project is on <a target='_blank' href='https://github.com/oliver-eifler/theater-pur'>github</a></p>";
        $html.="<p>Resize the window and any overflowing items will get stacked into the dropdown menu</p>";
        $html .= "<p>For internal use only</p>";
        $html .= "<p><span>" . $_SERVER['SERVER_NAME'] . " is created and maintained " . $Year . " with care* by</span> <a href='http://www.oliver-eifler.info'>".Component::get("svg","images/svg/ollidark.svg",["class"=>"icon icon-olli"])."Oliver Jean Eifler</a></p>";
        $html .= "<p class='text-smart legende'><small>*Not recommended for or tested with IE 9- or any other legacy browser</small></p>";
        return $html;
    }
}
Component::autoregister(__FILE__,new FooterComponent((int)date('Y',Config::getInstance()->baseTime)));