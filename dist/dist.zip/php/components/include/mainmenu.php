<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 09.07.2016
 * Time: 18:22
 * MainMenu Components
 */
class MainMenuComponent
{
    protected $class = "links";

    public function __construct($class = null)
    {
        if (isset($class))
            $this->class = $class;
    }

    public function __invoke()
    {
        $class= "ll";
        $html = "";
        $html .= "<ul class='".$class."'>";
        $html .= "<li class='".$class."-item'><a class='".$class."-link' href='/home' data-observe='ajax'>Home</a></li>";
        $html .= "<li class='".$class."-item'><a class='".$class."-link' href='/articles' data-observe='ajax'>Articles</a></li>";
        $html .= "<li class='".$class."-item'><a class='".$class."-link' href='/gallery' data-observe='ajax'>Gallery</a></li>";
        $html .= "</ul>";
        $html .= "<ul class='".$class."'>";
        $html .= "<li class='".$class."-item'><a class='".$class."-link' href='/about' data-observe='ajax'>About</a></li>";
        $html .= "<li class='".$class."-item'><a class='".$class."-link' href='/contact' data-observe='ajax'>Contact</a></li>";
        $html .= "<li class='".$class."-item'><a class='".$class."-link' href='/foo' data-observe='overlay'>Overlay</a></li>";
        //$html .= "<li class='".$class."-item'><a class='".$class."-link' href='/foo' data-observe='ajax'>Force 404</a></li>";
        $html .= "</ul>";
        return $html;
   }
}
