<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 09.07.2016
 * Time: 18:32
 * social menu components
 */
class SocialMenuComponent
{
    protected $class = "links";

    public function __construct($class = null)
    {
        if (isset($class))
            $this->class = $class;
    }

    public function __invoke()
    {
        $class= "ll";
        $html = "";

        $html .= "<ul class='" . $class . "'>";

        $html .= "<li class='" . $class . "-item'>";
        $html .=    "<a href=\"#\" class='" . $class . "-link' title=\"Olli on GitHub\">";
        $html .=        file_get_contents(RES."/github.svg");
        $html .=    "</a>";
        $html .= "</li>";

        $html .= "<li class='" . $class . "-item'>";
        $html .=    "<a href=\"#\" class='" . $class . "-link' title=\"Olli on Codepen\">";
        $html .=        file_get_contents(RES."/codepen.svg");
        $html .=    "</a>";
        $html .= "</li>";

        $html .= "<li class='" . $class . "-item'>";
        $html .=    "<a href=\"#\" class='" . $class . "-link' title=\"Olli on Twitter\">";
        $html .=        file_get_contents(RES."/twitter.svg");
        $html .=    "</a>";
        $html .= "</li>";

        $html .= "<li class='" . $class . "-item'>";
        $html .=    "<a href=\"#\" class='" . $class . "-link' title=\"Olli on Facebook\">";
        $html .=        file_get_contents(RES."/facebook.svg");
        $html .=    "</a>";
        $html .= "</li>";

        $html .= "<li class='" . $class . "-item'>";
        $html .=    "<a href=\"#\" class='" . $class . "-link' title=\"Olli on Google+\">";
        $html .=        file_get_contents(RES."/google.svg");
        $html .=    "</a>";
        $html .= "</li>";
        $html .= "<li class='" . $class . "-item'>";
        $html .=    "<a href=\"#\" class='" . $class . "-link' title=\"My Youtube Channel\">";
        $html .=        file_get_contents(RES."/youtube.svg");
        $html .=    "</a>";
        $html .= "</li>";

        $html .= "</ul>";

        return $html;
    }
}
