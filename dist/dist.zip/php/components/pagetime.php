<?php

/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 16.06.2016
 * Time: 17:38
 * PageTime Component
 */
class PageTimeComponent
{
    protected function printDate(DateTime $dateTime) {
        return $dateTime->format("j F, Y");
    }
    public function __invoke() {
        $page = PageData::GetInstance();
        if (empty($page->created))
            return "";
        $c = new DateTime();
        $c->setTimestamp($page->created);
        
        $str = "<p><small><em>";
        $str .= "published: <time datetime='".$c->format("c")."'>" . $this->printDate($c)."</time>";

        if (!empty($page->modified)) {
            $m = new DateTime();
            $m->setTimestamp($page->modified);
            if ($c->format('Y/m/d') != $m->format('Y/m/d'))
                $str .= " - modified: <time datetime='".$m->format("c")."'>"  . $this->printDate($m)."</time>";
        }
        $str .= "</em></small></p>";
        return $str;
    }
}
Component::autoregister(__FILE__,new PageTimeComponent());
