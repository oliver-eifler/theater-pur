<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 10.07.2016
 * Time: 16:36
 */
Component::autoregister(__FILE__,
    function() {
        $html = "";
        $page = PageData::GetInstance();
        $html .= "<meta charset='UTF-8'>";
        $html .= "<meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=yes'/>";
        $html .= "<meta name='format-detection' content='telephone=no'/>";
        $html .= "<title>" . (!empty($page->title)?$page->title:"Theater PUR") . "</title>";
        //$html .= "<link rel='icon' href='favicon.png'>";
        //$html .= "<link rel='apple-touch-icon' href='favicon.png'>";


        $html .= "<link rel='apple-touch-icon' sizes='180x180' href='/favicons/apple-touch-icon.png'>";
        $html .= "<link rel='icon' type='image/png' href='/favicons/favicon-32x32.png' sizes='32x32'>";
        $html .= "<link rel='icon' type='image/png' href='/favicons/favicon-16x16.png' sizes='16x16'>";
        $html .= "<link rel='manifest' href='/favicons/manifest.json'>";
        $html .= "<link rel='mask-icon' href='/favicons/safari-pinned-tab.svg' color='#ff8a00'>";
        $html .= "<link rel='shortcut icon' href='/favicons/favicon.ico'>";
        $html .= "<meta name='apple-mobile-web-app-title' content='Theater PUR'>";
        $html .= "<meta name='application-name' content='Theater PUR'>";
        $html .= "<meta name='msapplication-config' content='/favicons/browserconfig.xml'>";
        $html .= "<meta name='theme-color' content='#ff8a00'>";

        return $html;
    });
