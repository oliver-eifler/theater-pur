<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 03.12.2016
 * Time: 18:34
 * Inlude a svg inline images
 */
Component::register("svg",
    function ($path, $attrs = []) {
        $html = "";
        if (file_exists($path)) {
            $svg = file_get_contents($path);
            if (!isset($attrs["width"]))
                $attrs["width"] = 16;
            if (!isset($attrs["height"]))
                $attrs["height"] = 16;

            $str = "<svg";
            foreach ($attrs as $key => $value) {
                $str .= " " . $key . "='" . $value . "'";
            }
            $svg = str_replace("<svg", $str, $svg);

            $html = "<!--[if gt IE 8]><!-->";
            $html .= $svg;
            $html .= "<!--<![endif]-->";
        }
        return $html;
    });

?>