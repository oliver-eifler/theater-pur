<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 09.07.2016
 * Time: 17:43
 * Banner Component
 */
require_once("php/class/component.class.php");
require_once("php/class/pagedata.class.php");

class BannerComponent {
    protected $data = "";
    public function __construct($data="") {
        $this->data = $data;

}
    public function __invoke()
    {

        $html = "";
        $html .= "<header class='banner pattern'>";
        $html .=    "<div class='logo'>";
        //$html .=        "<div></div>";
        $html .=            Component::get("svg","images/svg/pur.svg",["class"=>"logo-pur","width"=>"270","height"=>"120"]);
        $html .=    "</div>";
        $html .=    "<ul class='sl social'>";
        $html .=        "<li><a href='#facebook' title='Theater PUR auf Facebook'>";
        $html .=            Component::get("svg","images/svg/facebook.svg",["class"=>"icon icon-facebook"]);
        $html .=        "</a></li>";
        $html .=        "<li><a href='#youtube' title='Theater PUR auf Youtube'>";
        $html .=            Component::get("svg","images/svg/youtubesm.svg",["class"=>"icon icon-youtube icon-youtube--small"]);
        $html .=            Component::get("svg","images/svg/youtube.svg",["class"=>"icon icon-youtube icon-youtube--wide"]);
        $html .=        "</a></li>";
        $html .=    "</ul>";
        $html .= "</header>";
        return $html;
    }
}
Component::autoregister(__FILE__,new BannerComponent());
