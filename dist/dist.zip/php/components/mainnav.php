<?php
/**
 * Created by PhpStorm.
 * User: darkwolf
 * Date: 09.07.2016
 * Time: 17:43
 * Banner Component
 */
require_once("php/class/component.class.php");
require_once("php/class/pagedata.class.php");

class MainNavComponent {
    protected $data = "";
    public function __construct($data="") {
        $this->data = $data;

}
    public function __invoke()
    {

        $html = "";
        $html .="<nav class='nav'>";
        $html .=    "<a class='nav-mainlink' href='home'>Aktuell:<br>Mein Freund Harvey</a>";
        $html .=    "<ul class='sl nav-links'>";
        $html .=        "<li><a href='termine'>Termine</a></li>";
        $html .=        "<li><a href='#'>Stücke</a></li>";
        $html .=        "<li><a href='#'>Wer sind wir</a></li>";
        $html .=        "<li><a href='kontakt'>Kontakt</a></li>";
        $html .=        "<li><a href='#'>Impressum</a></li>";
        $html .=    "</ul>";
        $html .=    "<button class='nav-button hidden'><span class='nav-button-text'>Mehr</span>";
        $html .=        Component::get("svg","images/svg/menu.svg",["class"=>"icon icon-open"]);
        $html .=        Component::get("svg","images/svg/cross.svg",["class"=>"icon icon-close"]);
        $html .=    "</button>";
        $html .=    "<ul class='sl nav-hidden-links hidden'></ul>";
        $html .="</nav>";
        return $html;
    }
}
Component::autoregister(__FILE__,new MainNavComponent());
