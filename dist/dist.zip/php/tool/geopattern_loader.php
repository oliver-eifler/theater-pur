<?php
// This file should only be used/included if you are not using Composer.

require_once(__DIR__.'/GeoPattern/SVGElements/Base.php');
require_once(__DIR__.'/GeoPattern/SVGElements/Circle.php');
require_once(__DIR__.'/GeoPattern/SVGElements/Group.php');
require_once(__DIR__.'/GeoPattern/SVGElements/Path.php');
require_once(__DIR__.'/GeoPattern/SVGElements/Polyline.php');
require_once(__DIR__.'/GeoPattern/SVGElements/Rectangle.php');
require_once(__DIR__.'/GeoPattern/SVG.php');
require_once(__DIR__.'/GeoPattern/GeoPattern.php');
