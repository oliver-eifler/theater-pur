<?php
$this->created = 1465034394;
$this->modified = 1474816719;
$this->title = "Termine";
$this->subtitle = "Wann und wo Sie unsere Vorstellungen sehen können";
$this->description = "Unsere Termine, Wann und wo Sie unsere Vorstellungen sehen können";
?>
<div class="text wrapper-narrow">
<p>[PLATZHALTER]</p>
</div>