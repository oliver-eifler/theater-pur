<?php
$this->created = 1465034394;
$this->modified = 1474816719;
$this->title = "Kontakt";
$this->subtitle = "Schreiben Sie uns einen Nachricht";
$this->description = "Mein Freund Harvey eine Krimikomödie von Holger Ptacek";
?>
<div class="text wrapper-narrow">
<p>[PLATZHALTER]</p>
</div>